package alignment;

public interface Scorer {
	public int getMatchScore(char c1, char c2);
	public int getGapPenalty();
}
