package alignment;

public class Aligner {
	private final Scorer scorer;
	public Aligner(Scorer scorer) {
		this.scorer = scorer;
	}

	public static void main(String[] args) {
		AffineScorer scorer = new AffineScorer() {
			@Override
			public int getMatchScore(char c1, char c2) {
				return c1 == c2 ? 2 : -2;
			}

			@Override
			public int getGapPenalty() {
				return -1;
			}

			@Override
			public int getGapOpenPenalty() {
				// TODO Auto-generated method stub
				return -2;
			}
		};

		Aligner aligner = new Aligner(scorer);
		
		System.out.println(aligner.getAffineAlignment("ATAAG", "ACCTG"));
	}
	
	public Alignment getAffineAlignment(String str1, String str2) {
		if (scorer instanceof AffineScorer) {
			AffineScorer aScorer = (AffineScorer)scorer;
			int[][] as = new int[str1.length() + 1][str2.length() + 1];
			int[][] bs = new int[str1.length() + 1][str2.length() + 1];
			int[][] cs = new int[str1.length() + 1][str2.length() + 1];
			Marker[][] markers = new Marker[str1.length() + 1][str2.length() + 1];
			as[0][0] = bs[0][0] = cs[0][0] = 0;
			markers[0][0] = Marker.START;
			for (int r = 1; r < as.length; r++) {
				as[r][0] = bs[r][0] = cs[r][0] = aScorer.getGapOpenPenalty() + (r - 1) * scorer.getGapPenalty();
				bs[r][0] += (aScorer.getGapOpenPenalty() - scorer.getGapPenalty());
				markers[r][0] = Marker.GAP2;
			}
			for (int c = 1; c < as[0].length; c++) {
				as[0][c] = bs[0][c] = cs[0][c] = aScorer.getGapOpenPenalty() + (c - 1) * scorer.getGapPenalty();
				cs[0][c] += (aScorer.getGapOpenPenalty() - scorer.getGapPenalty());
				markers[0][c] = Marker.GAP1;
			}
			
			for (int r = 1; r < as.length; r++) {
				for (int c = 1; c < as[r].length; c++) {
					int gapOpen1 = as[r][c-1] + aScorer.getGapOpenPenalty();
					int gapContinue1 = bs[r][c-1] + scorer.getGapPenalty();
					bs[r][c] = Math.max(gapOpen1, gapContinue1);
					int gapOpen2 = as[r-1][c] + aScorer.getGapOpenPenalty();
					int gapContinue2 = cs[r-1][c] + scorer.getGapPenalty();
					cs[r][c] = Math.max(gapOpen2, gapContinue2);
					
					int fromA = as[r-1][c-1] + scorer.getMatchScore(str1.charAt(r-1), str2.charAt(c-1));
					int fromB = bs[r][c];
					int fromC = cs[r][c];
					
					if (fromA >= fromB && fromA >= fromC) {
						as[r][c] = fromA;
						markers[r][c] = Marker.MATCH;
					} else if (fromB >= fromC) {
						as[r][c] = fromB;
						markers[r][c] = Marker.GAP1;
					} else {
						as[r][c] = fromC;
						markers[r][c] = Marker.GAP2;
					}
				}
			}
			
			int r = str1.length();
			int c = str2.length();
			int finalScore = as[r][c];
			String result1 = "";
			String result2 = "";
			while (markers[r][c] != Marker.START) {
				if (markers[r][c] == Marker.GAP1) {
					result1 = "-" + result1;
					result2 = str2.charAt(--c) + result2;
				} else if (markers[r][c] == Marker.GAP2) {
					result1 = str1.charAt(--r) + result1;
					result2 = "-" + result2;
				} else {
					result1 = str1.charAt(--r) + result1;
					result2 = str2.charAt(--c) + result2;
				}
			}

			return new Alignment(result1, result2, finalScore);
		}
		return null;
	}

	private enum Marker {
		MATCH, GAP1, GAP2, START
	}

	public Alignment getAlignment(String str1, String str2) {
		int[][] scores = new int[str1.length() + 1][str2.length() + 1];
		Marker[][] markers = new Marker[str1.length() + 1][str2.length() + 1];
		scores[0][0] = 0;
		markers[0][0] = Marker.START;
		for (int r = 1; r < scores.length; r++) {
			scores[r][0] = r * scorer.getGapPenalty();
			markers[r][0] = Marker.GAP2;
		}
		for (int c = 1; c < scores[0].length; c++) {
			scores[0][c] = c * scorer.getGapPenalty();
			markers[0][c] = Marker.GAP1;
		}

		for (int r = 1; r < scores.length; r++) {
			for (int c = 1; c < scores[r].length; c++) {
				int match = scorer.getMatchScore(str1.charAt(r - 1), str2.charAt(c - 1)) + scores[r-1][c-1];
				int gap1 = scorer.getGapPenalty() + scores[r][c - 1];
				int gap2 = scorer.getGapPenalty() + scores[r - 1][c];
				if (match >= gap1 && match >= gap2) {
					scores[r][c] = match;
					markers[r][c] = Marker.MATCH;
				} else if (gap1 >= gap2) {
					scores[r][c] = gap1;
					markers[r][c] = Marker.GAP1;
				} else {
					scores[r][c] = gap2;
					markers[r][c] = Marker.GAP2;
				}
			}
		}

		int r = str1.length();
		int c = str2.length();
		int finalScore = scores[r][c];
		String result1 = "";
		String result2 = "";
		while (markers[r][c] != Marker.START) {
			if (markers[r][c] == Marker.GAP1) {
				result1 = "-" + result1;
				result2 = str2.charAt(--c) + result2;
			} else if (markers[r][c] == Marker.GAP2) {
				result1 = str1.charAt(--r) + result1;
				result2 = "-" + result2;
			} else {
				result1 = str1.charAt(--r) + result1;
				result2 = str2.charAt(--c) + result2;
			}
		}

		return new Alignment(result1, result2, finalScore);
	}

	public Alignment getAlignmentRecursive(String str1, String str2) {
		if (str1.length() == 0) { // base case 1: str1 is empty
			int len = str2.length();
			return new Alignment(dashes(len),
					str2,
					scorer.getGapPenalty() * len);
		} else if (str2.length() == 0) { // base case 2: str2 is empty
			int len = str1.length();
			return new Alignment(str1,
					dashes(len),
					scorer.getGapPenalty() * len);
		}
		char c1 = str1.charAt(0);
		char c2 = str2.charAt(0);

		// match c1 to c2
		Alignment match = getAlignmentRecursive(str1.substring(1), str2.substring(1));
		int matchScore = match.getScore() + scorer.getMatchScore(c1, c2);

		// match c2 to a gap
		Alignment gap1 = getAlignmentRecursive(str1, str2.substring(1));
		int gap1Score = gap1.getScore() + scorer.getGapPenalty();

		// match c1 to a gap
		Alignment gap2 = getAlignmentRecursive(str1.substring(1), str2);
		int gap2Score = gap2.getScore() + scorer.getGapPenalty();

		// return the best one
		if (matchScore >= gap1Score && matchScore >= gap2Score) {
			return new Alignment(c1 + match.getStr1(),
					c2 + match.getStr2(),
					matchScore);
		} else if (gap1Score >= gap2Score) {
			return new Alignment("-" + gap1.getStr1(),
					c2 + gap1.getStr2(),
					gap1Score);
		} else {
			return new Alignment(c1 + gap2.getStr1(),
					"-" + gap2.getStr2(),
					gap2Score);
		}
	}

	private static String dashes(int len) {
		String result = "";
		for (int i = 0; i < len; i++) {
			result += "-";
		}
		return result;
	}
}
