package alignment;

public class Alignment {
	private final String str1;
	private final String str2;
	private final int score;
	
	public Alignment(String str1, String str2, int score) {
		this.str1 = str1;
		this.str2 = str2;
		this.score = score;
	}

	public String getStr1() {
		return str1;
	}

	public String getStr2() {
		return str2;
	}

	public int getScore() {
		return score;
	}
	
	public String toString() {
		return str1 + "\n" + str2 + "\n" + score;
	}
}
