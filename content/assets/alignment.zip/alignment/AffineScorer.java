package alignment;

public interface AffineScorer extends Scorer {
	public int getGapOpenPenalty();
}
